1. Создай шаблон на https://fabricmc.net/develop (Minecraft 1.21.11, Yarn, package com.example.coinbalance, mod id coinbalance).
2. Скопируй src/main/java/com/example/coinbalance/*.java и заменяй fabric.mod.json на этот (шаблонные Mixin/ModInitializer классы удали).
3. В build.gradle добавь (актуальные версии смотри на Modrinth):

repositories {
    maven { url = "https://maven.terraformersmc.com/" }
    maven { url = "https://maven.shedaniel.me/" }
}
dependencies {
    modImplementation "com.terraformersmc:modmenu:<версия для 1.21.11>"
    modImplementation("me.shedaniel.cloth:cloth-config-fabric:<версия для 1.21.11>") {
        exclude(group: "net.fabricmc.fabric-api")
    }
}

4. ./gradlew build -> build/libs/*.jar в папку mods (нужны Fabric API, Mod Menu, Cloth Config).
