package com.example.coinbalance;

import net.minecraft.client.MinecraftClient;
import net.minecraft.scoreboard.ScoreboardEntry;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.Team;
import net.minecraft.text.Text;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class ScoreboardReader {
    // цветовые коды вида §a, §l и т.п.
    private static final Pattern FORMAT_CODES = Pattern.compile("§.");
    // число с пробелами, запятыми или точками внутри: 24,999 / 1 250 / 1.250
    private static final Pattern NUMBER = Pattern.compile("\\d[\\d.,\\s\\u00A0]*\\d|\\d");

    private ScoreboardReader() {}

    /** Возвращает число из строки скорборда, которая содержит keyword, или null. */
    public static Long readCoins(String keyword) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return null;

        Scoreboard sb = mc.world.getScoreboard();
        ScoreboardObjective obj = sb.getObjectiveForSlot(ScoreboardDisplaySlot.SIDEBAR);
        if (obj == null) return null;

        String key = keyword.toLowerCase();
        for (ScoreboardEntry entry : sb.getScoreboardEntries(obj)) {
            String holder = entry.owner().getNameForScoreboard();
            Text name = entry.name() != null ? entry.name() : Text.literal(holder);

            Team team = sb.getScoreHolderTeam(holder);
            String line = team != null
                    ? team.decorateName(name).getString()
                    : name.getString();

            String clean = FORMAT_CODES.matcher(line).replaceAll("");
            if (!clean.toLowerCase().contains(key)) continue;

            int colon = clean.indexOf(':');
            String after = colon >= 0 ? clean.substring(colon + 1) : clean;

            Matcher m = NUMBER.matcher(after);
            if (m.find()) {
                String digits = m.group().replaceAll("[^0-9]", "");
                if (!digits.isEmpty()) {
                    try {
                        return Long.parseLong(digits);
                    } catch (NumberFormatException ignored) {
                        return null;
                    }
                }
            }
        }
        return null;
    }
}
