package com.example.coinbalance;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigCategory;
import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
import net.minecraft.text.Text;

public class ModMenuIntegration implements ModMenuApi {
    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return parent -> {
            CoinConfig cfg = CoinConfig.INSTANCE;
            ConfigBuilder builder = ConfigBuilder.create()
                    .setParentScreen(parent)
                    .setTitle(Text.literal("Coin Balance"))
                    .setSavingRunnable(CoinConfig::save);

            ConfigCategory cat = builder.getOrCreateCategory(Text.literal("Основное"));
            ConfigEntryBuilder eb = builder.entryBuilder();

            cat.addEntry(eb.startBooleanToggle(Text.literal("Показывать на экране"), cfg.enabled)
                    .setDefaultValue(true)
                    .setSaveConsumer(v -> cfg.enabled = v).build());

            cat.addEntry(eb.startDoubleField(Text.literal("Баланс (в монетах)"), cfg.balance)
                    .setDefaultValue(0)
                    .setSaveConsumer(v -> cfg.balance = v).build());

            cat.addEntry(eb.startDoubleField(Text.literal("Курс койна (монет за 1 койн)"), cfg.rate)
                    .setDefaultValue(1)
                    .setMin(0.0000001)
                    .setSaveConsumer(v -> cfg.rate = v).build());

            cat.addEntry(eb.startStrField(Text.literal("Подпись"), cfg.suffix)
                    .setDefaultValue("coin")
                    .setSaveConsumer(v -> cfg.suffix = v).build());

            cat.addEntry(eb.startStrField(Text.literal("Ключ в скорборде"), cfg.keyword)
                    .setDefaultValue("Монеток")
                    .setSaveConsumer(v -> cfg.keyword = v).build());

            ConfigCategory pos = builder.getOrCreateCategory(Text.literal("Положение и цвет"));

            pos.addEntry(eb.startIntField(Text.literal("X (отступ справа)"), cfg.offsetX)
                    .setDefaultValue(4)
                    .setSaveConsumer(v -> cfg.offsetX = v).build());

            pos.addEntry(eb.startIntField(Text.literal("Y (отступ снизу)"), cfg.offsetY)
                    .setDefaultValue(4)
                    .setSaveConsumer(v -> cfg.offsetY = v).build());

            pos.addEntry(eb.startBooleanToggle(Text.literal("Тень у текста"), cfg.shadow)
                    .setDefaultValue(true)
                    .setSaveConsumer(v -> cfg.shadow = v).build());

            pos.addEntry(eb.startIntSlider(Text.literal("Красный (R)"), cfg.red, 0, 255)
                    .setDefaultValue(255)
                    .setSaveConsumer(v -> cfg.red = v).build());

            pos.addEntry(eb.startIntSlider(Text.literal("Зелёный (G)"), cfg.green, 0, 255)
                    .setDefaultValue(255)
                    .setSaveConsumer(v -> cfg.green = v).build());

            pos.addEntry(eb.startIntSlider(Text.literal("Синий (B)"), cfg.blue, 0, 255)
                    .setDefaultValue(255)
                    .setSaveConsumer(v -> cfg.blue = v).build());

            return builder.build();
        };
    }
}
