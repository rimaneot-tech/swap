package com.example.coinbalance;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

public class CoinBalanceClient implements ClientModInitializer {
    private static final DecimalFormat FORMAT =
            new DecimalFormat("#,##0.####", DecimalFormatSymbols.getInstance(Locale.US));

    @Override
    public void onInitializeClient() {
        CoinConfig.load();
        HudElementRegistry.attachElementAfter(
                VanillaHudElements.CHAT,
                Identifier.of("coinbalance", "balance"),
                (context, tickCounter) -> render(context)
        );
    }

    private void render(DrawContext context) {
        CoinConfig cfg = CoinConfig.INSTANCE;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!cfg.enabled || mc.options.hudHidden) return;

        Long parsed = ScoreboardReader.readCoins(cfg.keyword);
        double balance = parsed != null ? parsed : cfg.balance; // запасной вариант: ручной баланс
        double coins = cfg.rate > 0 ? balance / cfg.rate : 0;
        String text = FORMAT.format(coins) + " " + cfg.suffix;

        TextRenderer tr = mc.textRenderer;
        int x = context.getScaledWindowWidth() - tr.getWidth(text) - cfg.offsetX;
        int y = context.getScaledWindowHeight() - tr.fontHeight - cfg.offsetY;
        if (cfg.shadow) {
            context.drawTextWithShadow(tr, text, x, y, cfg.argb());
        } else {
            context.drawText(tr, text, x, y, cfg.argb(), false);
        }
    }
}
