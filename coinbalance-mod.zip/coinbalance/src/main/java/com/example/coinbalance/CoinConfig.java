package com.example.coinbalance;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public class CoinConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("coinbalance.json");

    public boolean enabled = true;
    public double balance = 0;      // баланс в монетах
    public double rate = 1;         // курс: сколько монет в 1 койне
    public String suffix = "coin";  // подпись после числа
    public String keyword = "Монеток"; // ключ строки в скорборде
    public int offsetX = 4;   // отступ от правого края, пикселей
    public int offsetY = 4;   // отступ от нижнего края, пикселей
    public int red = 255;     // цвет текста RGB
    public int green = 255;
    public int blue = 255;
    public boolean shadow = true;

    public int argb() {
        return 0xFF000000 | (clamp(red) << 16) | (clamp(green) << 8) | clamp(blue);
    }

    private static int clamp(int v) {
        return Math.max(0, Math.min(255, v));
    }

    public static CoinConfig INSTANCE = new CoinConfig();

    public static void load() {
        try {
            if (Files.exists(FILE)) {
                CoinConfig c = GSON.fromJson(Files.readString(FILE), CoinConfig.class);
                if (c != null) INSTANCE = c;
            } else {
                save();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void save() {
        try {
            Files.writeString(FILE, GSON.toJson(INSTANCE));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
