AutoSwap (Fabric, Minecraft 1.21.11)

Сборка:
1. Проверьте версии в gradle.properties (https://fabricmc.net/develop).
2. Скопируйте gradle wrapper (gradlew, gradle/) из шаблона с fabricmc.net/develop
   или выполните `gradle wrapper` при установленном Gradle.
3. ./gradlew build  ->  build/libs/autoswap-1.0.0.jar
4. Положите jar в mods вместе с Fabric API и Mod Menu.

Бинд: Настройки -> Управление -> AutoSwap (по умолчанию R).
Настройки: Mod Menu -> AutoSwap (режим, задержка 150-500 мс).
