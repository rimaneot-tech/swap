package com.example.autoswap;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

public class AutoSwapScreen extends Screen {
    private final Screen parent;

    public AutoSwapScreen(Screen parent) {
        super(Text.translatable("autoswap.title"));
        this.parent = parent;
    }

    private Text modeText() {
        String key = AutoSwapConfig.mode == AutoSwapConfig.Mode.TOTEM_TO_SPHERE
            ? "autoswap.mode.totem" : "autoswap.mode.sphere";
        return Text.translatable("autoswap.mode", Text.translatable(key));
    }

    @Override
    protected void init() {
        int cx = width / 2, cy = height / 2;

        addDrawableChild(ButtonWidget.builder(modeText(), b -> {
            AutoSwapConfig.mode = AutoSwapConfig.mode == AutoSwapConfig.Mode.TOTEM_TO_SPHERE
                ? AutoSwapConfig.Mode.SPHERE_TO_SPHERE : AutoSwapConfig.Mode.TOTEM_TO_SPHERE;
            b.setMessage(modeText());
        }).dimensions(cx - 100, cy - 30, 200, 20).build());

        addDrawableChild(new DelaySlider(cx - 100, cy, 200, 20));

        addDrawableChild(ButtonWidget.builder(Text.translatable("gui.done"), b -> close())
            .dimensions(cx - 100, cy + 30, 200, 20).build());
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, height / 2 - 60, 0xFFFFFFFF);
    }

    @Override
    public void close() {
        AutoSwapConfig.save();
        client.setScreen(parent);
    }

    private static class DelaySlider extends SliderWidget {
        DelaySlider(int x, int y, int w, int h) {
            super(x, y, w, h, Text.empty(), (AutoSwapConfig.delay - 150) / 350.0);
            updateMessage();
        }
        @Override
        protected void updateMessage() {
            setMessage(Text.translatable("autoswap.delay", AutoSwapConfig.delay));
        }
        @Override
        protected void applyValue() {
            AutoSwapConfig.delay = 150 + (int) Math.round(value * 350);
            updateMessage();
        }
    }
}
