package com.example.autoswap;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.*;

public class AutoSwapConfig {
    public enum Mode { TOTEM_TO_SPHERE, SPHERE_TO_SPHERE }

    public static Mode mode = Mode.TOTEM_TO_SPHERE;
    public static int delay = 300; // 150..500

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE =
        FabricLoader.getInstance().getConfigDir().resolve("autoswap.json");

    public static void load() {
        try {
            if (Files.exists(FILE)) {
                JsonObject o = JsonParser.parseString(Files.readString(FILE)).getAsJsonObject();
                mode = Mode.valueOf(o.get("mode").getAsString());
                delay = Math.max(150, Math.min(500, o.get("delay").getAsInt()));
            }
        } catch (Exception ignored) {}
    }

    public static void save() {
        try {
            JsonObject o = new JsonObject();
            o.addProperty("mode", mode.name());
            o.addProperty("delay", delay);
            Files.writeString(FILE, GSON.toJson(o));
        } catch (Exception ignored) {}
    }
}
