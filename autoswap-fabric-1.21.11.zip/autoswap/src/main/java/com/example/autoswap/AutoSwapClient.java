package com.example.autoswap;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;

public class AutoSwapClient implements ClientModInitializer {
    public static KeyBinding swapKey;
    private static final ScheduledExecutorService SCHEDULER =
        Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "autoswap");
            t.setDaemon(true);
            return t;
        });
    private static volatile boolean pending = false;

    @Override
    public void onInitializeClient() {
        AutoSwapConfig.load();

        KeyBinding.Category category =
            KeyBinding.Category.create(Identifier.of("autoswap", "main"));
        swapKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.autoswap.swap", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_R, category));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (swapKey.wasPressed()) {
                if (pending || mc.player == null) continue;
                pending = true;
                SCHEDULER.schedule(() -> mc.execute(() -> {
                    try { doSwap(mc); } finally { pending = false; }
                }), AutoSwapConfig.delay, TimeUnit.MILLISECONDS);
            }
        });
    }

    private static void doSwap(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null) return;

        ItemStack off = p.getOffHandStack();
        int slot = -1;

        switch (AutoSwapConfig.mode) {
            case TOTEM_TO_SPHERE -> {
                if (off.isOf(Items.PLAYER_HEAD))
                    slot = find(p, s -> s.isOf(Items.TOTEM_OF_UNDYING));
                else
                    slot = find(p, s -> s.isOf(Items.PLAYER_HEAD));
            }
            case SPHERE_TO_SPHERE -> {
                if (off.isOf(Items.PLAYER_HEAD))
                    slot = find(p, s -> s.isOf(Items.PLAYER_HEAD) && !ItemStack.areEqual(s, off));
            }
        }
        if (slot == -1) return;

        // button 40 = обмен с оффхендом
        mc.interactionManager.clickSlot(0, slot, 40, SlotActionType.SWAP, p);
    }

    /** Возвращает ID слота в PlayerScreenHandler или -1 */
    private static int find(ClientPlayerEntity p, Predicate<ItemStack> test) {
        for (int i = 0; i < 36; i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (!s.isEmpty() && test.test(s)) {
                return i < 9 ? 36 + i : i;
            }
        }
        return -1;
    }
}
