package com.example.swap;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.*;

public class SwapConfig {
    public enum Mode { TOTEM_TO_SPHERE, SPHERE_TO_SPHERE }

    public static Mode mode = Mode.TOTEM_TO_SPHERE;
    public static int delay = 300;               // 150..500 мс
    public static boolean openInventory = true;  // открывать/закрывать инвентарь при свапе
    public static String coinRate = "1";        // сколько игровых монет стоит 1 койн

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE =
        FabricLoader.getInstance().getConfigDir().resolve("swap.json");

    public static void load() {
        try {
            if (Files.exists(FILE)) {
                JsonObject o = JsonParser.parseString(Files.readString(FILE)).getAsJsonObject();
                if (o.has("mode")) mode = Mode.valueOf(o.get("mode").getAsString());
                if (o.has("delay")) delay = Math.max(150, Math.min(500, o.get("delay").getAsInt()));
                if (o.has("openInventory")) openInventory = o.get("openInventory").getAsBoolean();
                if (o.has("coinRate")) coinRate = o.get("coinRate").getAsString();
            }
        } catch (Exception ignored) {}
    }

    public static void save() {
        try {
            JsonObject o = new JsonObject();
            o.addProperty("mode", mode.name());
            o.addProperty("delay", delay);
            o.addProperty("openInventory", openInventory);
            o.addProperty("coinRate", coinRate);
            Files.writeString(FILE, GSON.toJson(o));
        } catch (Exception ignored) {}
    }
}
