package com.example.swap;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;

public class SwapClient implements ClientModInitializer {
    public static KeyBinding swapKey;
    private static final ScheduledExecutorService SCHEDULER =
        Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "swap");
            t.setDaemon(true);
            return t;
        });
    private static volatile boolean pending = false;

    @Override
    public void onInitializeClient() {
        SwapConfig.load();

        KeyBinding.Category category =
            KeyBinding.Category.create(Identifier.of("swap", "main"));
        swapKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.swap.swap", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_R, category));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (swapKey.wasPressed()) {
                if (pending || mc.player == null || mc.currentScreen != null) continue;
                pending = true;

                // 1. быстро открываем инвентарь
                boolean opened = false;
                if (SwapConfig.openInventory) {
                    mc.setScreen(new InventoryScreen(mc.player));
                    opened = true;
                }
                final boolean closeAfter = opened;

                // 2. через delay мс делаем свап и закрываем инвентарь
                SCHEDULER.schedule(() -> mc.execute(() -> {
                    try {
                        doSwap(mc);
                    } finally {
                        if (closeAfter && mc.player != null
                                && mc.currentScreen instanceof InventoryScreen) {
                            mc.player.closeHandledScreen();
                        }
                        pending = false;
                    }
                }), SwapConfig.delay, TimeUnit.MILLISECONDS);
            }
        });
    }

    private static void doSwap(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null) return;

        ItemStack off = p.getOffHandStack();
        int slot = -1;

        switch (SwapConfig.mode) {
            case TOTEM_TO_SPHERE -> {
                if (off.isOf(Items.PLAYER_HEAD))
                    slot = find(p, s -> s.isOf(Items.TOTEM_OF_UNDYING));
                else
                    slot = find(p, s -> s.isOf(Items.PLAYER_HEAD));
            }
            case SPHERE_TO_SPHERE -> {
                if (off.isOf(Items.PLAYER_HEAD))
                    slot = find(p, s -> s.isOf(Items.PLAYER_HEAD) && !ItemStack.areEqual(s, off));
            }
        }
        if (slot == -1) return;

        // button 40 = обмен с оффхендом
        mc.interactionManager.clickSlot(0, slot, 40, SlotActionType.SWAP, p);
    }

    /** Возвращает ID слота в PlayerScreenHandler или -1 */
    private static int find(ClientPlayerEntity p, Predicate<ItemStack> test) {
        for (int i = 0; i < 36; i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (!s.isEmpty() && test.test(s)) {
                return i < 9 ? 36 + i : i;
            }
        }
        return -1;
    }
}
