package com.example.swap;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;

public class CoinHud {
    public static void register() {
        HudRenderCallback.EVENT.register((ctx, tick) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.options.hudHidden) return;
            if (SwapConfig.coinRate == null || SwapConfig.coinRate.isBlank()) return;

            String text = "1 койн = " + SwapConfig.coinRate + " монет";
            int w = mc.textRenderer.getWidth(text);
            int x = ctx.getScaledWindowWidth() - w - 4;
            int y = ctx.getScaledWindowHeight() - 12;
            ctx.drawTextWithShadow(mc.textRenderer, text, x, y, 0xFFFFFF);
        });
    }
}
