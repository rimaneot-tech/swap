package com.example.swap;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

public class SwapScreen extends Screen {
    private final Screen parent;
    private net.minecraft.client.gui.widget.TextFieldWidget rateField;

    public SwapScreen(Screen parent) {
        super(Text.translatable("swap.title"));
        this.parent = parent;
    }

    private Text modeText() {
        String key = SwapConfig.mode == SwapConfig.Mode.TOTEM_TO_SPHERE
            ? "swap.mode.totem" : "swap.mode.sphere";
        return Text.translatable("swap.mode", Text.translatable(key));
    }

    private Text invText() {
        return Text.translatable("swap.inventory",
            Text.translatable(SwapConfig.openInventory ? "swap.on" : "swap.off"));
    }

    @Override
    protected void init() {
        int cx = width / 2, cy = height / 2;

        addDrawableChild(ButtonWidget.builder(modeText(), b -> {
            SwapConfig.mode = SwapConfig.mode == SwapConfig.Mode.TOTEM_TO_SPHERE
                ? SwapConfig.Mode.SPHERE_TO_SPHERE : SwapConfig.Mode.TOTEM_TO_SPHERE;
            b.setMessage(modeText());
        }).dimensions(cx - 100, cy - 40, 200, 20).build());

        addDrawableChild(ButtonWidget.builder(invText(), b -> {
            SwapConfig.openInventory = !SwapConfig.openInventory;
            b.setMessage(invText());
        }).dimensions(cx - 100, cy - 14, 200, 20).build());

        addDrawableChild(new DelaySlider(cx - 100, cy + 12, 200, 20));

        rateField = new net.minecraft.client.gui.widget.TextFieldWidget(
            textRenderer, cx - 100, cy + 70, 200, 20, Text.empty());
        rateField.setMaxLength(12);
        rateField.setText(SwapConfig.coinRate);
        rateField.setChangedListener(str -> SwapConfig.coinRate = str);
        addDrawableChild(rateField);

        addDrawableChild(ButtonWidget.builder(Text.translatable("gui.done"), b -> close())
            .dimensions(cx - 100, cy + 44, 200, 20).build());
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, height / 2 - 70, 0xFFFFFFFF);
        ctx.drawTextWithShadow(textRenderer, Text.literal("Курс: монет за 1 койн"),
            width / 2 - 100, height / 2 + 58, 0xFFFFFFFF);
    }

    @Override
    public void close() {
        SwapConfig.save();
        client.setScreen(parent);
    }

    private static class DelaySlider extends SliderWidget {
        DelaySlider(int x, int y, int w, int h) {
            super(x, y, w, h, Text.empty(), (SwapConfig.delay - 150) / 350.0);
            updateMessage();
        }
        @Override
        protected void updateMessage() {
            setMessage(Text.translatable("swap.delay", SwapConfig.delay));
        }
        @Override
        protected void applyValue() {
            SwapConfig.delay = 150 + (int) Math.round(value * 350);
            updateMessage();
        }
    }
}
